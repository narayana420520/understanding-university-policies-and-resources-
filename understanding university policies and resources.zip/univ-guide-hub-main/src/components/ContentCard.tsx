import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Globe, Mail } from "lucide-react";

interface ContentCardProps {
  title: string;
  description: string;
  category: string;
  content?: string;
  contactInfo?: string;
  location?: string;
  websiteUrl?: string;
  onClick?: () => void;
}

const categoryColors: Record<string, string> = {
  academic: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  conduct: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  financial: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  health_safety: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  student_services: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  technology: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200",
  housing: "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200",
  other: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200",
};

const ContentCard = ({ 
  title, 
  description, 
  category, 
  contactInfo, 
  location, 
  websiteUrl,
  onClick 
}: ContentCardProps) => {
  const categoryLabel = category.split('_').map(word => 
    word.charAt(0).toUpperCase() + word.slice(1)
  ).join(' ');

  return (
    <Card 
      className="h-full hover:shadow-elevated transition-all duration-300 cursor-pointer group"
      onClick={onClick}
    >
      <CardHeader>
        <div className="flex items-start justify-between mb-2">
          <CardTitle className="text-xl group-hover:text-primary transition-colors">{title}</CardTitle>
          <Badge className={categoryColors[category] || categoryColors.other}>
            {categoryLabel}
          </Badge>
        </div>
        <CardDescription className="text-base">{description}</CardDescription>
      </CardHeader>
      
      {(contactInfo || location || websiteUrl) && (
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          {contactInfo && (
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-accent" />
              <span>{contactInfo}</span>
            </div>
          )}
          {location && (
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-accent" />
              <span>{location}</span>
            </div>
          )}
          {websiteUrl && (
            <div className="flex items-center gap-2">
              <Globe className="h-4 w-4 text-accent" />
              <a 
                href={websiteUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="hover:text-primary transition-colors"
                onClick={(e) => e.stopPropagation()}
              >
                Visit Website
              </a>
            </div>
          )}
        </CardContent>
      )}
    </Card>
  );
};

export default ContentCard;
