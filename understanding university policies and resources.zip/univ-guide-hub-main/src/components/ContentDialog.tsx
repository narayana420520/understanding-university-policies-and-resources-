import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { MapPin, Globe, Mail } from "lucide-react";

interface ContentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  content: string;
  category: string;
  contactInfo?: string;
  location?: string;
  websiteUrl?: string;
}

const categoryColors: Record<string, string> = {
  academic: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  conduct: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  financial: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  health_safety: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  student_services: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  technology: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200",
  housing: "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200",
  other: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200",
};

const ContentDialog = ({
  open,
  onOpenChange,
  title,
  description,
  content,
  category,
  contactInfo,
  location,
  websiteUrl,
}: ContentDialogProps) => {
  const categoryLabel = category.split('_').map(word => 
    word.charAt(0).toUpperCase() + word.slice(1)
  ).join(' ');

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between mb-2">
            <DialogTitle className="text-2xl pr-8">{title}</DialogTitle>
            <Badge className={categoryColors[category] || categoryColors.other}>
              {categoryLabel}
            </Badge>
          </div>
          <DialogDescription className="text-base">{description}</DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 pt-4">
          <div className="prose prose-sm max-w-none dark:prose-invert">
            <p className="text-foreground whitespace-pre-wrap">{content}</p>
          </div>
          
          {(contactInfo || location || websiteUrl) && (
            <div className="border-t pt-4 space-y-3">
              <h4 className="font-semibold text-sm text-muted-foreground">Contact Information</h4>
              {contactInfo && (
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="h-4 w-4 text-accent" />
                  <span>{contactInfo}</span>
                </div>
              )}
              {location && (
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="h-4 w-4 text-accent" />
                  <span>{location}</span>
                </div>
              )}
              {websiteUrl && (
                <div className="flex items-center gap-2 text-sm">
                  <Globe className="h-4 w-4 text-accent" />
                  <a 
                    href={websiteUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="hover:text-primary transition-colors underline"
                  >
                    Visit Website
                  </a>
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ContentDialog;
