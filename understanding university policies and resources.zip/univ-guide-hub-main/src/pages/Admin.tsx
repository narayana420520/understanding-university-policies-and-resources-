import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Plus, Edit, Trash2 } from "lucide-react";
import { z } from "zod";

const contentSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters").max(200, "Title must be less than 200 characters"),
  description: z.string().min(10, "Description must be at least 10 characters").max(500, "Description must be less than 500 characters"),
  content: z.string().min(20, "Content must be at least 20 characters").max(5000, "Content must be less than 5000 characters"),
  category: z.string().min(1, "Category is required"),
});

const resourceSchema = contentSchema.extend({
  contactInfo: z.string().max(200, "Contact info must be less than 200 characters").optional(),
  location: z.string().max(200, "Location must be less than 200 characters").optional(),
  websiteUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
});

interface Policy {
  id: string;
  title: string;
  description: string;
  content: string;
  category: string;
  is_active: boolean;
}

interface Resource extends Policy {
  contact_info?: string;
  location?: string;
  website_url?: string;
}

const Admin = () => {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [policies, setPolicies] = useState<Policy[]>([]);
  const [resources, setResources] = useState<Resource[]>([]);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    content: "",
    category: "",
    contactInfo: "",
    location: "",
    websiteUrl: "",
  });
  const [editingId, setEditingId] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      } else {
        checkAdminRole(session.user.id);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      } else {
        checkAdminRole(session.user.id);
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const checkAdminRole = async (userId: string) => {
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle();
    
    if (!data) {
      toast.error("Access denied. Admin privileges required.");
      navigate("/");
    } else {
      setIsAdmin(true);
      fetchPolicies();
      fetchResources();
    }
  };

  const fetchPolicies = async () => {
    const { data, error } = await supabase
      .from("policies")
      .select("*")
      .order("created_at", { ascending: false });

    if (!error && data) {
      setPolicies(data);
    }
  };

  const fetchResources = async () => {
    const { data, error } = await supabase
      .from("resources")
      .select("*")
      .order("created_at", { ascending: false });

    if (!error && data) {
      setResources(data);
    }
  };

  const resetForm = () => {
    setFormData({
      title: "",
      description: "",
      content: "",
      category: "",
      contactInfo: "",
      location: "",
      websiteUrl: "",
    });
    setEditingId(null);
  };

  const handleSubmitPolicy = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const validated = contentSchema.parse({
        title: formData.title,
        description: formData.description,
        content: formData.content,
        category: formData.category,
      });

      const policyData = {
        title: validated.title,
        description: validated.description,
        content: validated.content,
        category: validated.category as "academic" | "conduct" | "financial" | "health_safety" | "student_services" | "technology" | "housing" | "other",
      };

      if (editingId) {
        const { error } = await supabase
          .from("policies")
          .update(policyData)
          .eq("id", editingId);

        if (error) throw error;
        toast.success("Policy updated successfully");
      } else {
        const { error } = await supabase
          .from("policies")
          .insert([policyData]);

        if (error) throw error;
        toast.success("Policy created successfully");
      }

      resetForm();
      fetchPolicies();
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      } else {
        toast.error("Failed to save policy");
      }
    }
  };

  const handleSubmitResource = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const validated = resourceSchema.parse({
        title: formData.title,
        description: formData.description,
        content: formData.content,
        category: formData.category,
        contactInfo: formData.contactInfo,
        location: formData.location,
        websiteUrl: formData.websiteUrl,
      });

      const resourceData = {
        title: validated.title,
        description: validated.description,
        content: validated.content,
        category: validated.category as "academic" | "conduct" | "financial" | "health_safety" | "student_services" | "technology" | "housing" | "other",
        contact_info: validated.contactInfo || null,
        location: validated.location || null,
        website_url: validated.websiteUrl || null,
      };

      if (editingId) {
        const { error } = await supabase
          .from("resources")
          .update(resourceData)
          .eq("id", editingId);

        if (error) throw error;
        toast.success("Resource updated successfully");
      } else {
        const { error } = await supabase
          .from("resources")
          .insert([resourceData]);

        if (error) throw error;
        toast.success("Resource created successfully");
      }

      resetForm();
      fetchResources();
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      } else {
        toast.error("Failed to save resource");
      }
    }
  };

  const handleEdit = (item: Policy | Resource, type: "policy" | "resource") => {
    setFormData({
      title: item.title,
      description: item.description,
      content: item.content,
      category: item.category,
      contactInfo: "contact_info" in item ? item.contact_info || "" : "",
      location: "location" in item ? item.location || "" : "",
      websiteUrl: "website_url" in item ? item.website_url || "" : "",
    });
    setEditingId(item.id);
  };

  const handleDelete = async (id: string, type: "policy" | "resource") => {
    if (!confirm("Are you sure you want to delete this item?")) return;

    const table = type === "policy" ? "policies" : "resources";
    const { error } = await supabase.from(table).delete().eq("id", id);

    if (error) {
      toast.error("Failed to delete item");
    } else {
      toast.success("Item deleted successfully");
      if (type === "policy") {
        fetchPolicies();
      } else {
        fetchResources();
      }
    }
  };

  if (!session || !isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar isAdmin={isAdmin} />
      
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-muted-foreground text-lg">
            Manage university policies and campus resources
          </p>
        </div>

        <Tabs defaultValue="policies" className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="policies">Policies</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
          </TabsList>

          <TabsContent value="policies" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{editingId ? "Edit Policy" : "Add New Policy"}</CardTitle>
                <CardDescription>Create or update university policies</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmitPolicy} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="policy-title">Title</Label>
                    <Input
                      id="policy-title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="policy-category">Category</Label>
                    <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="academic">Academic</SelectItem>
                        <SelectItem value="conduct">Conduct</SelectItem>
                        <SelectItem value="financial">Financial</SelectItem>
                        <SelectItem value="health_safety">Health & Safety</SelectItem>
                        <SelectItem value="student_services">Student Services</SelectItem>
                        <SelectItem value="technology">Technology</SelectItem>
                        <SelectItem value="housing">Housing</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="policy-description">Description</Label>
                    <Textarea
                      id="policy-description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      rows={3}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="policy-content">Content</Label>
                    <Textarea
                      id="policy-content"
                      value={formData.content}
                      onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                      rows={6}
                      required
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button type="submit" className="gap-2">
                      {editingId ? <Edit className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                      {editingId ? "Update" : "Create"} Policy
                    </Button>
                    {editingId && (
                      <Button type="button" variant="outline" onClick={resetForm}>
                        Cancel
                      </Button>
                    )}
                  </div>
                </form>
              </CardContent>
            </Card>

            <div className="space-y-4">
              <h3 className="text-2xl font-semibold">Existing Policies</h3>
              {policies.length === 0 ? (
                <p className="text-muted-foreground">No policies yet</p>
              ) : (
                <div className="grid gap-4">
                  {policies.map((policy) => (
                    <Card key={policy.id}>
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle>{policy.title}</CardTitle>
                            <CardDescription>{policy.description}</CardDescription>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => handleEdit(policy, "policy")}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="destructive" onClick={() => handleDelete(policy.id, "policy")}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="resources" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{editingId ? "Edit Resource" : "Add New Resource"}</CardTitle>
                <CardDescription>Create or update campus resources</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmitResource} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="resource-title">Title</Label>
                    <Input
                      id="resource-title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="resource-category">Category</Label>
                    <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="academic">Academic</SelectItem>
                        <SelectItem value="conduct">Conduct</SelectItem>
                        <SelectItem value="financial">Financial</SelectItem>
                        <SelectItem value="health_safety">Health & Safety</SelectItem>
                        <SelectItem value="student_services">Student Services</SelectItem>
                        <SelectItem value="technology">Technology</SelectItem>
                        <SelectItem value="housing">Housing</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="resource-description">Description</Label>
                    <Textarea
                      id="resource-description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      rows={3}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="resource-content">Content</Label>
                    <Textarea
                      id="resource-content"
                      value={formData.content}
                      onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                      rows={6}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="resource-contact">Contact Information</Label>
                    <Input
                      id="resource-contact"
                      value={formData.contactInfo}
                      onChange={(e) => setFormData({ ...formData, contactInfo: e.target.value })}
                      placeholder="email@example.com | (555) 123-4567"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="resource-location">Location</Label>
                    <Input
                      id="resource-location"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      placeholder="Building name, Room number"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="resource-website">Website URL</Label>
                    <Input
                      id="resource-website"
                      type="url"
                      value={formData.websiteUrl}
                      onChange={(e) => setFormData({ ...formData, websiteUrl: e.target.value })}
                      placeholder="https://example.com"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button type="submit" className="gap-2">
                      {editingId ? <Edit className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                      {editingId ? "Update" : "Create"} Resource
                    </Button>
                    {editingId && (
                      <Button type="button" variant="outline" onClick={resetForm}>
                        Cancel
                      </Button>
                    )}
                  </div>
                </form>
              </CardContent>
            </Card>

            <div className="space-y-4">
              <h3 className="text-2xl font-semibold">Existing Resources</h3>
              {resources.length === 0 ? (
                <p className="text-muted-foreground">No resources yet</p>
              ) : (
                <div className="grid gap-4">
                  {resources.map((resource) => (
                    <Card key={resource.id}>
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle>{resource.title}</CardTitle>
                            <CardDescription>{resource.description}</CardDescription>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => handleEdit(resource, "resource")}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="destructive" onClick={() => handleDelete(resource.id, "resource")}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Admin;
