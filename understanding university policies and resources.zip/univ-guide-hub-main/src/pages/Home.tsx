import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, BookOpen, LifeBuoy, Shield } from "lucide-react";

const Home = () => {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      } else {
        checkAdminRole(session.user.id);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      } else {
        checkAdminRole(session.user.id);
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const checkAdminRole = async (userId: string) => {
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle();
    
    setIsAdmin(!!data);
  };

  const handleSearch = () => {
    if (searchQuery.trim()) {
      navigate(`/policies?search=${encodeURIComponent(searchQuery)}`);
    }
  };

  if (!session) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar isAdmin={isAdmin} />
      
      <main className="container mx-auto px-4 py-12">
        <section className="text-center mb-16">
          <div className="max-w-3xl mx-auto space-y-6">
            <h1 className="text-5xl font-bold bg-gradient-hero bg-clip-text text-transparent">
              University Portal
            </h1>
            <p className="text-xl text-muted-foreground">
              Access university policies, resources, and support services all in one place
            </p>
            
            <div className="flex gap-2 max-w-2xl mx-auto mt-8">
              <Input
                placeholder="Search policies and resources..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                className="text-lg h-12"
              />
              <Button onClick={handleSearch} size="lg" className="gap-2">
                <Search className="h-5 w-5" />
                Search
              </Button>
            </div>
          </div>
        </section>

        <section className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <Card className="hover:shadow-elevated transition-all duration-300 cursor-pointer group" onClick={() => navigate("/policies")}>
            <CardHeader>
              <div className="p-3 bg-primary/10 rounded-lg w-fit mb-4 group-hover:bg-primary/20 transition-colors">
                <BookOpen className="h-8 w-8 text-primary" />
              </div>
              <CardTitle>University Policies</CardTitle>
              <CardDescription>
                Browse and understand academic, conduct, and administrative policies
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="ghost" className="w-full justify-start text-primary group-hover:translate-x-2 transition-transform">
                View Policies →
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-elevated transition-all duration-300 cursor-pointer group" onClick={() => navigate("/resources")}>
            <CardHeader>
              <div className="p-3 bg-accent/10 rounded-lg w-fit mb-4 group-hover:bg-accent/20 transition-colors">
                <LifeBuoy className="h-8 w-8 text-accent" />
              </div>
              <CardTitle>Campus Resources</CardTitle>
              <CardDescription>
                Find support services, facilities, and helpful resources for students
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="ghost" className="w-full justify-start text-accent group-hover:translate-x-2 transition-transform">
                View Resources →
              </Button>
            </CardContent>
          </Card>

          {isAdmin && (
            <Card className="hover:shadow-elevated transition-all duration-300 cursor-pointer group" onClick={() => navigate("/admin")}>
              <CardHeader>
                <div className="p-3 bg-destructive/10 rounded-lg w-fit mb-4 group-hover:bg-destructive/20 transition-colors">
                  <Shield className="h-8 w-8 text-destructive" />
                </div>
                <CardTitle>Admin Panel</CardTitle>
                <CardDescription>
                  Manage policies, resources, and user permissions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="ghost" className="w-full justify-start text-destructive group-hover:translate-x-2 transition-transform">
                  Admin Dashboard →
                </Button>
              </CardContent>
            </Card>
          )}
        </section>
      </main>
    </div>
  );
};

export default Home;
